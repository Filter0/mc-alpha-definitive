package net.minecraft.src;

public class ModelPig extends ModelQuadraped {
	public ModelPig() {
		super(6, 0.0F);
	}

	public ModelPig(float f1) {
		super(6, f1);
	}
}
