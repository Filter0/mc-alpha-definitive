package net.minecraft.src;

import java.io.DataInputStream;
import java.io.DataOutputStream;

public class Packet0KeepAlive extends Packet {
	public void processPacket(NetHandler netHandler) {
	}

	public void readPacketData(DataInputStream dataInputStream) {
	}

	public void writePacket(DataOutputStream dataOutputStream) {
	}

	public int getPacketSize() {
		return 0;
	}
}
