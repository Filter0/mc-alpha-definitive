package com.jcraft.jorbis;

class Floor0$LookFloor0 {
	int n;
	int ln;
	int m;
	int[] linearmap;
	Floor0$InfoFloor0 vi;
	Lpc lpclook;
	final Floor0 this$0;

	Floor0$LookFloor0(Floor0 floor01) {
		this.this$0 = floor01;
		this.lpclook = new Lpc();
	}
}
