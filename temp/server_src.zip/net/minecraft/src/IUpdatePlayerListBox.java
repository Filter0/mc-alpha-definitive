package net.minecraft.src;

public interface IUpdatePlayerListBox {
	void addAllPlayers();
}
