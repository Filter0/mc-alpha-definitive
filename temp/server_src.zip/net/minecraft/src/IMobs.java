package net.minecraft.src;

public interface IMobs extends IAnimals {
}
