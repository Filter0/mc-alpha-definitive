package net.minecraft.src;

public interface ICommandListener {
	void addHelpCommandMessage(String string1);

	String getUsername();
}
